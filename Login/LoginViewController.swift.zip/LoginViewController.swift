//
//  LoginViewController.swift
//  Lasagu
//
//  Created by Arun Vijayan on 29/06/20.
//  Copyright © 2020 Arun Vijayan. All rights reserved.
//

import UIKit


extension UIViewController{
    
    func showToast(message : String, font: UIFont , duration: Double) {
        
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/4 - 85, y: self.view.frame.size.height-100, width: UIScreen.main.bounds.width-30, height: 40))
        //toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.backgroundColor = UIColor.darkGray
        toastLabel.textColor = UIColor.white
        toastLabel.font = font
        toastLabel.textAlignment = .center;
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 5;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 7, delay: 1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    } }

func showAlert(text:String, classInstance:UIViewController) {
    let alert = UIAlertController(title: "Alert", message: text, preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
        switch action.style{
        case .default:
            print("default")
            
        case .cancel:
            print("cancel")
            
        case .destructive:
            print("destructive")
            
            
        }}))
    classInstance.present(alert, animated: true, completion: nil)
}




class LoginViewController: UIViewController {
    @IBOutlet weak var viewlogin: UIView!
    
    @IBOutlet weak var txtfldemail: UITextField!
    
    @IBOutlet weak var txtfldpassword: UITextField!
    var helper=LoginHelper()
    var userID:String?
    var noInternetView:NoInternetView?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewlogin.setShadowEffect()
        let model=LoginViewModel()
        model.loginUser()
        
       
    }
    
    
       
    
//    @IBAction func btnfrgotpswrdaction(_ sender: Any) {
//
//    }
//
//
//
//    @IBAction func btncontinuuepressed(_ sender: Any) {
//        if txtfldemail.text?.count == 0 {
//            self.showToast(message: "Please enter registered email id", font: UIFont.boldSystemFont(ofSize: 14),duration: 2)
//
//        }else  if txtfldpassword.text?.count == 0{
//            self.showToast(message: "Please enter password", font: UIFont.boldSystemFont(ofSize: 14),duration: 2)
//
//        }else{
//            loginUser(username: txtfldemail.text!, password: txtfldpassword.text!)
//        }
//    }
//
//
//
//
//    @IBAction func btndonthaveaccountaction(_ sender: Any) {
//       let registration = self.storyboard?.instantiateViewController (withIdentifier: "RegistrationViewController") as! RegistrationViewController
//
//        self.navigationController?.pushViewController(registration, animated: true)
//
//    }
//
//
//    func loginUser(username:String,password:String)  {
//
//        guard ((NetworkManager.sharedInstance.reachability?.connection ?? .unavailable) != .unavailable) else {
//            checkInternetAvailability()
//            return
//        }
//
//
//
//        //self.showIndicator(isHidden: false)
//        let url = URL(string: "http://pscrank.com/psc_coaching_admin/api/Data/login_user_new")!
//        let poststring="username=\(username)&password=\(password)&device_id=2"
//
//        var request = NSMutableURLRequest(url: url as URL)
//        request.httpMethod = "POST"
//        request.httpBody = poststring.data(using: String.Encoding.utf8)
//        let task=URLSession.shared.dataTask(with: request as URLRequest){data,response,error in
//
//            //self.showIndicator(isHidden: true)
//            if error != nil{
//                print("error",error)
//                return
//            }
//            let responsestring=NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
//
//            print("respnsedate,\(responsestring)")
//            do {
//
//                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
//
//                if let parseJson = json{
//                    let status=parseJson["status"]as! Bool
//                    let message=parseJson["message"] as! String
//                    if status==true{
//                        let dataarray=parseJson["data"] as! NSArray
//                        for value in dataarray{
//                            let item=value as! [String:Any]
//                        let psc_user_id=item["psc_user_id"] as! String
//                        let psc_first_name=item["psc_first_name"] as! String
//                        let psc_last_name=item["psc_last_name"] as! String
//                        let psc_email=item["psc_email"] as! String
//                        let psc_phone=item["psc_phone"] as! String
//                        let userInfo = ["name":psc_first_name, "phone":psc_phone,"email": psc_email,"userid": psc_user_id] as [String : Any]
//                        UserDefaults.standard.set(userInfo, forKey: "UserData")
//                        let userdata = UserDefaults.standard.dictionary(forKey: "UserData")
//                        print("userdata",userdata)
//                        }
//                        DispatchQueue.main.async {
//                            self.showToast(message: message, font: UIFont.boldSystemFont(ofSize: 14),duration: 2)
//
//
//                        }
//                    }else{
//                        DispatchQueue.main.async {
//                            self.showToast(message: message, font: UIFont.boldSystemFont(ofSize: 14),duration: 2)
//                        }
//                    }
//                } else {
//                    DispatchQueue.main.async{
//                        showAlert(text: "Please check your credentials", classInstance: self)
//                    }
//                }
//
//            } catch let error as NSError {
//            }
//        }
//        task.resume()
//    }
//    func populateCell(data:[String:Any]) {
//    }
//
//}
//
//extension LoginViewController : NoInternetViewDelegate {
//func retry() {
//
//}
//
//func checkInternetAvailability() {
//
//    let connection = (NetworkManager.sharedInstance.reachability?.connection ?? .unavailable)
//
//    if connection == .unavailable {
//        guard self.noInternetView == nil else {
//            return
//        }
//        self.noInternetView = NoInternetView.fromNib(named: "NoInternetView")
//        self.noInternetView?.retryButton.isHidden = true
//        self.noInternetView?.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height - 45, width: UIScreen.main.bounds.size.width, height: 45)
//        self.noInternetView?.viewDelegate = self
//        self.view.addSubview(self.noInternetView!);
//        self.view.bringSubviewToFront(self.noInternetView!)
//    } else {
//        self.noInternetView?.removeFromSuperview()
//        self.noInternetView = nil
//    }
//
//}
//
//@objc func networkStatusChanged() {
//    checkInternetAvailability()
//}
}
