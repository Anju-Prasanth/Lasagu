//
//  Loginmodelclass.swift
//  Lasagu
//
//  Created by Arun Vijayan on 04/07/20.
//  Copyright © 2020 Arun Vijayan. All rights reserved.
//

import Foundation
struct Data : Codable {
    let psc_user_id : String?
    let psc_first_name : String?
    let psc_last_name : String?
    let psc_email : String?
    let psc_phone : String?
    let psc_password : String?
    let psc_premium_member : String?
    let last_login : String?
    let login_time : String?
    let created_at : String?
    let status : String?

    enum CodingKeys: String, CodingKey {

        case psc_user_id = "psc_user_id"
        case psc_first_name = "psc_first_name"
        case psc_last_name = "psc_last_name"
        case psc_email = "psc_email"
        case psc_phone = "psc_phone"
        case psc_password = "psc_password"
        case psc_premium_member = "psc_premium_member"
        case last_login = "last_login"
        case login_time = "login_time"
        case created_at = "created_at"
        case status = "status"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        psc_user_id = try values.decodeIfPresent(String.self, forKey: .psc_user_id)
        psc_first_name = try values.decodeIfPresent(String.self, forKey: .psc_first_name)
        psc_last_name = try values.decodeIfPresent(String.self, forKey: .psc_last_name)
        psc_email = try values.decodeIfPresent(String.self, forKey: .psc_email)
        psc_phone = try values.decodeIfPresent(String.self, forKey: .psc_phone)
        psc_password = try values.decodeIfPresent(String.self, forKey: .psc_password)
        psc_premium_member = try values.decodeIfPresent(String.self, forKey: .psc_premium_member)
        last_login = try values.decodeIfPresent(String.self, forKey: .last_login)
        login_time = try values.decodeIfPresent(String.self, forKey: .login_time)
        created_at = try values.decodeIfPresent(String.self, forKey: .created_at)
        status = try values.decodeIfPresent(String.self, forKey: .status)
    }
    
   

}
struct Json4Swift_Base : Codable {
    let data : [Data]?
    let status : Bool?
    let message : String?

    enum CodingKeys: String, CodingKey {

        case data = "data"
        case status = "status"
        case message = "message"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        data = try values.decodeIfPresent([Data].self, forKey: .data)
        status = try values.decodeIfPresent(Bool.self, forKey: .status)
        message = try values.decodeIfPresent(String.self, forKey: .message)
    }

}
