//
//  LoginViewModel.swift
//  Lasagu
//
//  Created by Arun Vijayan on 04/07/20.
//  Copyright © 2020 Arun Vijayan. All rights reserved.
//

import Foundation
public class LoginViewModel {
   
    var logindata=[Data]()
var successHandler:(([[String:Any]]) -> Void)?
var errorHandler:((String) -> Void)?


    
    func loginUser()  {
            
            let url = URL(string: "http://pscrank.com/psc_coaching_admin/api/Data/login_user_new")!
            let poststring="username=anju@infintor.com&password=123456&device_id=2"
            
            var request = NSMutableURLRequest(url: url as URL)
            request.httpMethod = "POST"
            request.httpBody = poststring.data(using: String.Encoding.utf8)
            let task=URLSession.shared.dataTask(with: request as URLRequest){data,response,error in
                
                //self.showIndicator(isHidden: true)
                if error != nil{
                    print("error",error)
                    return
                }
                let responsestring=NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                
                print("respnsedate,\(responsestring)")
                do {
                    
                   
                        let decoder = JSONDecoder()
                        let model = try decoder.decode(Json4Swift_Base.self, from:
                            data!) //Decode JSON Response Data
                        print(model)
                        
                    
                    
                } catch let error as NSError {
                }
            }
            task.resume()
        }
        
    }
    
    
    
    
    
    
    
    
    



